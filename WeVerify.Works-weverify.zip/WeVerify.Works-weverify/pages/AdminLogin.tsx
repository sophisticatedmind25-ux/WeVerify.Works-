
import React, { useState } from 'react';
import { Shield, Lock, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { auth, signInWithEmailAndPassword } from '../src/services/storage';

const AdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    identifier: '',
    password: ''
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const identifier = formData.identifier.trim();
      const password = formData.password.trim();

      // Default Admin Bypass (Case-insensitive for identifier)
      const isDefaultAdmin = (identifier.toLowerCase() === 'admin' || identifier.toLowerCase() === 'admin@weverify.works') && password === 'admin123';
      
      if (isDefaultAdmin) {
        console.log('Default admin bypass triggered');
        localStorage.setItem('wv_admin_auth', 'true');
        localStorage.setItem('wv_admin_email', 'admin@weverify.works');
        localStorage.setItem('wv_admin_name', 'System Administrator');
        localStorage.setItem('wv_local_admin', 'true');
        navigate('/admin/dashboard');
        return;
      }

      const email = identifier.includes('@') ? identifier : `${identifier}@weverify.works`;
      
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Sync with legacy localStorage for compatibility
      localStorage.setItem('wv_admin_auth', 'true');
      localStorage.setItem('wv_admin_email', user.email || '');
      
      navigate('/admin/dashboard');
    } catch (err: any) {
      console.error('Admin login error:', err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password login is disabled. Please check the system configuration or use the default admin credentials.');
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError('Invalid team credentials. Access denied.');
      } else if (err.message) {
        setError(`Authentication failed: ${err.message}`);
      } else {
        setError('Authentication failed. Please try again.');
      }
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl p-10">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-red-100 shadow-lg">
             <Shield className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight mb-2">Weverify Team CMS</h1>
          <p className="text-slate-500 font-medium text-sm">Secure affiliate and employee access portal.</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center space-x-3 text-red-600 text-xs font-bold uppercase tracking-wider">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2 ml-2">Username / Email</label>
            <input 
              required
              type="text" 
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition-all"
              placeholder="Username or Email"
              value={formData.identifier}
              onChange={(e) => setFormData({...formData, identifier: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2 ml-2">Access Key</label>
            <div className="relative">
              <input 
                required
                type="password" 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition-all pr-12"
                placeholder="••••••••••••"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
              />
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
            </div>
          </div>

          <div className="flex flex-col space-y-3">
            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg hover:bg-slate-800 transition-all shadow-xl flex items-center justify-center space-x-2 mt-4"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                <>
                  <span>Authorize Access</span>
                  <ArrowRight className="w-5 h-5 text-red-400" />
                </>
              )}
            </button>

            <button 
              type="button"
              onClick={() => {
                setFormData({ identifier: 'admin', password: 'admin123' });
                // We don't trigger submit automatically to let the user see the values
              }}
              className="w-full py-3 bg-slate-100 text-slate-600 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all flex items-center justify-center space-x-2 border border-slate-200"
            >
              <span>Use Default Admin Credentials</span>
            </button>
          </div>
        </form>

        <div className="mt-12 flex items-center justify-center space-x-2 text-[10px] text-slate-300 font-black uppercase tracking-widest">
           <Shield className="w-3 h-3 text-red-600/30" />
           <span>Team CMS Access Active</span>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;

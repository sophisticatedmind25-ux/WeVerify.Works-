
// Mock Storage and Auth using localStorage
// This replaces the real Firebase SDK to ensure data persistence without external dependencies

// Mock Auth
export const auth: any = {
  get currentUser() {
    const adminAuth = localStorage.getItem('wv_admin_auth') === 'true';
    const userAuth = localStorage.getItem('wv_auth') === 'true';
    const email = localStorage.getItem('wv_admin_email') || localStorage.getItem('wv_user_email');
    
    if (adminAuth || userAuth) {
      return {
        uid: 'local-user-id',
        email: email,
        displayName: localStorage.getItem('wv_admin_name') || 'User'
      };
    }
    return null;
  },
  onAuthStateChanged: (callback: any) => {
    const checkAuth = () => {
      const email = localStorage.getItem('wv_admin_email') || localStorage.getItem('wv_user_email');
      if (email) {
        callback({ email, uid: 'local-user-id', displayName: localStorage.getItem('wv_admin_name') || 'User' });
      } else {
        callback(null);
      }
    };
    checkAuth();
    window.addEventListener('storage', checkAuth);
    return () => window.removeEventListener('storage', checkAuth);
  }
};

// Mock Firestore
export const db: any = {};

// Helper to get data from localStorage
const getLocalData = (collectionName: string) => {
  const data = localStorage.getItem(`wv_db_${collectionName}`);
  return data ? JSON.parse(data) : [];
};

// Helper to save data to localStorage
const saveLocalData = (collectionName: string, data: any[]) => {
  localStorage.setItem(`wv_db_${collectionName}`, JSON.stringify(data));
  window.dispatchEvent(new Event('storage'));
};

// Mock Firestore functions
export const collection = (db: any, name: string) => ({ name, type: 'collection' });
export const doc = (db: any, name: string, id?: string) => ({ name, id, type: 'doc' });
export const query = (col: any, ...args: any[]) => col;
export const where = (...args: any[]) => ({ type: 'where', args });
export const orderBy = (...args: any[]) => ({ type: 'orderBy', args });
export const limit = (n: number) => ({ type: 'limit', n });
export const serverTimestamp = () => new Date().toISOString();
export const arrayUnion = (item: any) => ({ type: 'arrayUnion', item });
export const increment = (n: number) => ({ type: 'increment', n });

export const onSnapshot = (ref: any, callback: any, errorCallback?: any) => {
  const collectionName = ref.name;
  const emit = () => {
    const data = getLocalData(collectionName);
    const snapshot = {
      docs: data.map((item: any) => ({
        id: item.id || item.uid,
        data: () => item,
        exists: () => true
      }))
    };
    callback(snapshot);
  };
  emit();
  window.addEventListener('storage', emit);
  return () => window.removeEventListener('storage', emit);
};

export const getDoc = async (docRef: any) => {
  const data = getLocalData(docRef.name);
  const item = data.find((i: any) => (i.id || i.uid) === docRef.id);
  return {
    exists: () => !!item,
    data: () => item
  };
};

export const getDocs = async (queryRef: any) => {
  const data = getLocalData(queryRef.name);
  return {
    docs: data.map((item: any) => ({
      id: item.id || item.uid,
      data: () => item
    }))
  };
};

export const setDoc = async (docRef: any, data: any, options?: any) => {
  const collectionData = getLocalData(docRef.name);
  const id = docRef.id;
  const index = collectionData.findIndex((i: any) => (i.id || i.uid) === id);
  
  if (index !== -1) {
    if (options && options.merge) {
      collectionData[index] = { ...collectionData[index], ...data, id };
    } else {
      collectionData[index] = { ...data, id };
    }
  } else {
    collectionData.push({ ...data, id });
  }
  saveLocalData(docRef.name, collectionData);
};

export const updateDoc = async (docRef: any, data: any) => {
  const collectionData = getLocalData(docRef.name);
  const id = docRef.id;
  const index = collectionData.findIndex((i: any) => (i.id || i.uid) === id);
  
  if (index !== -1) {
    const updatedItem = { ...collectionData[index] };
    Object.keys(data).forEach(key => {
      const value = data[key];
      if (value && value.type === 'increment') {
        updatedItem[key] = (updatedItem[key] || 0) + value.n;
      } else if (value && value.type === 'arrayUnion') {
        updatedItem[key] = [...(updatedItem[key] || []), value.item];
      } else {
        updatedItem[key] = value;
      }
    });
    collectionData[index] = updatedItem;
    saveLocalData(docRef.name, collectionData);
  }
};

export const addDoc = async (colRef: any, data: any) => {
  const collectionData = getLocalData(colRef.name);
  const id = Math.random().toString(36).substring(2, 15);
  const newItem = { ...data, id, createdAt: new Date().toISOString() };
  collectionData.push(newItem);
  saveLocalData(colRef.name, collectionData);
  return { id };
};

export const deleteDoc = async (docRef: any) => {
  const collectionData = getLocalData(docRef.name);
  const id = docRef.id;
  const filtered = collectionData.filter((i: any) => (i.id || i.uid) !== id);
  saveLocalData(docRef.name, filtered);
};

export const writeBatch = (db: any) => {
  const operations: any[] = [];
  return {
    set: (docRef: any, data: any) => operations.push({ type: 'set', docRef, data }),
    update: (docRef: any, data: any) => operations.push({ type: 'update', docRef, data }),
    delete: (docRef: any) => operations.push({ type: 'delete', docRef }),
    commit: async () => {
      for (const op of operations) {
        if (op.type === 'set') await setDoc(op.docRef, op.data);
        if (op.type === 'update') await updateDoc(op.docRef, op.data);
        if (op.type === 'delete') await deleteDoc(op.docRef);
      }
    }
  };
};

// Auth functions
export const signOut = async (authInstance: any) => {
  localStorage.removeItem('wv_auth');
  localStorage.removeItem('wv_admin_auth');
  localStorage.removeItem('wv_user_email');
  localStorage.removeItem('wv_admin_email');
  localStorage.removeItem('wv_local_admin');
  localStorage.removeItem('wv_admin_name');
  window.dispatchEvent(new Event('storage'));
};

export const signInWithEmailAndPassword = async (authInstance: any, email: string, pass: string) => {
  return { user: { email, uid: 'local-user-id' } };
};

export const createUserWithEmailAndPassword = async (authInstance: any, email: string, pass: string) => {
  return { user: { email, uid: 'local-user-id' } };
};

export const getDocFromServer = async (docRef: any) => {
  return getDoc(docRef);
};

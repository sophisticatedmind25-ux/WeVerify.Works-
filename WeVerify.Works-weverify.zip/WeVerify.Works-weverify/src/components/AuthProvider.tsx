import React, { createContext, useContext, useEffect, useState } from 'react';

interface AuthContextType {
  user: any | null;
  userData: any | null;
  loading: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userData: null,
  loading: true,
  isAdmin: false,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null);
  const [userData, setUserData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAuth = () => {
      const adminAuth = localStorage.getItem('wv_admin_auth') === 'true';
      const userAuth = localStorage.getItem('wv_auth') === 'true';
      const email = localStorage.getItem('wv_admin_email') || localStorage.getItem('wv_user_email');
      const name = localStorage.getItem('wv_admin_name') || 'User';
      
      if (adminAuth || userAuth) {
        const mockUser = {
          email: email,
          uid: 'local-user-id',
          displayName: name
        };
        setUser(mockUser);
        setIsAdmin(adminAuth);
        setUserData({
          email: email,
          role: adminAuth ? 'admin' : 'user',
          tokens: parseInt(localStorage.getItem('wv_tokens') || '0'),
          orgName: name
        });
      } else {
        setUser(null);
        setIsAdmin(false);
        setUserData(null);
      }
      setLoading(false);
    };

    checkAuth();
    
    // Listen for storage changes (for cross-tab logout/login)
    window.addEventListener('storage', checkAuth);
    return () => window.removeEventListener('storage', checkAuth);
  }, []);

  return (
    <AuthContext.Provider value={{ user, userData, loading, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};

export const StorageErrorBoundary: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return <>{children}</>;
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleStorageError(error: unknown, operationType: OperationType, path: string | null) {
  console.error(`Storage Error (${operationType} on ${path}):`, error);
}
